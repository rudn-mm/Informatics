//
// copybmp.c
// Просто копирует BMP файл по кусочкам
//
       
#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int main(int argc, char* argv[])
{
    // Проверка аргументов
    if (argc != 3)
    {
        printf("Ошибка\nИспользуйте вызов: ./copybmp infile outfile\n");
        return 1;
    }

    char* infile = argv[1];
    char* outfile = argv[2];

    // Открытие исходного файла 
    FILE* inptr = fopen(infile, "rb");
    if (inptr == NULL)
    {
        printf("Ошибка: Невозможно открыть файл %s.\n", infile);
        return 2;
    }

    // Создание нового файла
    FILE* outptr = fopen(outfile, "wb");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Ошибка: Невозможно создать файл %s.\n", outfile);
        return 3;
    }

    // Чтение BITMAPFILEHEADER
    BITMAPFILEHEADER bf;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

    // Чтение BITMAPINFOHEADER
    BITMAPINFOHEADER bi;
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);

    // Проверка, что исходный файл является файлом формата BMP
    if (bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 || 
        bi.biBitCount != 24 || bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Ошибка: Неправильный формат файла!\n");
        return 4;
    }

    // Запись BITMAPFILEHEADER
    fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, outptr);

    // Запись BITMAPINFOHEADER
    fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, outptr);

    // Вычисление числа дополнительных байт для строк
    int padding =  (4 - (bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;

    // Цикл по строкам исходного файла
    for (int i = 0, biHeight = abs(bi.biHeight); i < biHeight; i++)
    {
        // Цикл по пикселям каждой строки
        for (int j = 0; j < bi.biWidth; j++)
        {
            RGBTRIPLE triple;

            // Чтение пикселя
            fread(&triple, sizeof(RGBTRIPLE), 1, inptr);

            // Запись пикселя
            fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
        }

        // Сдвиг на число дополнительных байт в исходном файле
        fseek(inptr, padding, SEEK_CUR);

        // Запись дополнительных байт в новый файл
        for (int k = 0; k < padding; k++)
        {
            fputc(0x00, outptr);
        }
    }

    fclose(inptr);
    fclose(outptr);
    return 0;
}