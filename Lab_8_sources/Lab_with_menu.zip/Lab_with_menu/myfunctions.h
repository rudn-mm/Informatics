#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int fill_array(int a[]);
int find_max(int a[], int n);
int find_min(int a[], int n);
int find_element(int a[], int n, int value);